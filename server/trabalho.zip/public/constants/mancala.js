const MESSAGE = {
    playerTurn: name => `${name}, it is your turn to play`,
    otherTurn: name => `It is ${name}'s turn`,
    aiTurn: () => "It is AI's turn",
}