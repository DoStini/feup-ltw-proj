let CONFIG = {
    API_HOSTNAME: "http://localhost:8080/",
}

function getApiHost() {
    return CONFIG.API_HOSTNAME;
}
