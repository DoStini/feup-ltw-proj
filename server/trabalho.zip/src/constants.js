module.exports = {
    OK: 0,
    WRONG_TURN: -1,
    INVALID_HOLE: -2,
    GAME_END: 1
}