class DatabaseModel {
    /** @property {string} name */
    name;

    /** @param {string} name */
    constructor (name) {
        this.name = name;
    }

    async setup() {

    }

    /**
     * 
     * @param {*} key 
     */
    async find(key) {

    }

    async findByKey(key, value) {
        
    }

    async insert(key, val) {
        
    }

    async update(key, val, obj) {

    }

    async delete(key, val) {

    }

    async all() {
        
    }

}

module.exports = DatabaseModel;

